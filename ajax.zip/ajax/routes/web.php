<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/student', 'StudentController@index')->name('student.index');
Route::get('/studentRecords', 'StudentController@show')->name('student.show');
Route::get('/editstudentRecords/{id}', 'StudentController@edit')->name('student.edit');
Route::put('/updatestudentRecords/{id}', 'StudentController@update')->name('student.update');
Route::delete('/deletestudentRecords/{id}', 'StudentController@destroy')->name('student.delete');
Route::post('student', 'StudentController@store')->name('student.store');
Route::delete('/selected_student', 'StudentController@deleteAllRecords')->name('student.selected');

Route::get('/home', 'HomeController@index');
