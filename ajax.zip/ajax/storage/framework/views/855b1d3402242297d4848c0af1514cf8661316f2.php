<?php $__env->startSection('content'); ?>
    <!-- add studentModal -->
    <div class="modal fade" id="addstudentmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Student</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <ul id="saveform_error"> </ul>
                <div class="modal-body">
                   <div class="form-group mb-3">
                       <label for="name">Name</label>
                       <input type="text" class="name form-control">
                   </div>
                    <div class="form-group mb-3">
                        <label for="email">Email</label>
                        <input type="email" class="email form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary add_student">Save</button>
                </div>
            </div>
        </div>
    </div>
    <!-- endadd studentModal -->

    <!-- delete studentModal -->
    <div class="modal fade" id="deletestudentmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Student</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <input type="text" id="student_id">
                    <h4>Are you sure? want to delete this data</h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary delete_student_btn">Yes Delete</button>
                </div>
            </div>
        </div>
    </div>
    <!-- end delete studentModal -->

    <!-- edit studentModal -->
    <div class="modal fade" id="editstudentmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">edit Student</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <ul id="updateform_error"> </ul>
                <div class="modal-body">
                    <input type="hidden" id="student_id">
                    <div class="form-group mb-3">
                        <label for="name">Name</label>
                        <input type="text" id="edit_name" class="name form-control">
                    </div>
                    <div class="form-group mb-3">
                        <label for="email">Email</label>
                        <input type="email" id="edit_email" class="email form-control">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary update_student">Update</button>
                </div>
            </div>
        </div>
    </div>
    <!-- end edit studentModal -->

    <div class="py-5">
      <div class="row">
          <div class="col-md-12">
              <div id="success"></div>
            <div class="card">
               <div class="card-header">
                   <h4>Student Data
                       <a href="#" class="btn btn-primary float-end btn-sm" data-bs-toggle="modal" data-bs-target="#addstudentmodal">Add Student</a>
                       <a href="#" class="btn btn-danger" id="deleteAllSelectRecords">Delete All</a>
                   </h4>
               </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <td><input type="checkbox" name="" id="checkedall"></td>
                         <td>So NO</td>
                         <td>Name</td>
                         <td>Email</td>
                        </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
          </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script !src="">
        $(document).ready(function (){
            fetchRecord();
            function  fetchRecord(){
                $.ajax({
                   type:"GET",
                   url:"<?php echo e(route('student.show')); ?>",
                   datatype: "json",
                    success:function (response){
                       $('tbody').html("");
                     $.each(response.student, function (key, item) {
                      $('tbody').append('<tr id="ids'+item.id+'">\
                           <td><input type="checkbox" name="ids" class="checkBoxClass" value="'+item.id +'"></td>\
                          <td>'+item.id +'</td>\
                           <td>'+item.name +'</td>\
                           <td>'+item.email +'</td>\
                         <td><button type="button" value="'+ item.id+'" class="btn btn-primary btn-sm edit_student">Edit</button></td>\
                         <td><button type="button" value="'+ item.id+'" class="btn btn-danger btn-sm delete_student">Delete</button></td>\
                     </tr>');
                     });
                    }
                });
            }
            $(document).on('click', '.delete_student', function (e){
                e.preventDefault();
               var student_id = $(this).val();
               $('#student_id').val(student_id);
              $('#deletestudentmodal').modal('show');
            });
            $(document).on('click', '.delete_student_btn', function (e){
                e.preventDefault();
                var student_id = $('#student_id').val();
                var url = '<?php echo e(route("student.delete", ":student_id")); ?>';
                url = url.replace(':student_id', student_id);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                     type:"DELETE",
                     url:url,
                    success:function (response){
                        if (response.status == 200){
                            $('#success').addClass('alert alert-success');
                            $('#success').text(response.message);
                            $('#deletestudentmodal').modal('hide');
                            fetchRecord();
                        }
                    }
                });
            });
            $(document).on('click', '.edit_student', function (e) {
               e.preventDefault();
               var student_id = $(this).val();
               $('#editstudentmodal').modal("show");
                var url = '<?php echo e(route("student.edit", ":student_id")); ?>';
                url = url.replace(':student_id', student_id);
               $.ajax({
                  type:"GET",
                  url:url,
                   success:function (response){
                   // console.log(response);
                       if (response.status == 402){
                           $('#success_message').html("");
                           $('#success_message').addClass("alert alert-danger");
                           $('#success_message').text(response.messages);
                       }
                       else {
                           $('#edit_name').val(response.student.name);
                           $('#edit_email').val(response.student.email);
                           $('#student_id').val(student_id);
                       }
                   }
               });

            });

            $(document).on('click', '.update_student', function (e){
                e.preventDefault();
                $(this).text("Updating");
                var student_id = $('#student_id').val();
                var url = '<?php echo e(route("student.update", ":student_id")); ?>';
                url = url.replace(':student_id', student_id);
                var data = {
                 'name':$('#edit_name').val(),
                 'email':$('#edit_email').val(),
                }
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type:"PUT",
                    datatype:"json",
                    data:data,
                    url:url,
                    success:function (response){
                        // console.log(response);
                        if (response.status == 400){
                            $('#updateform_error').html("");
                            $('#updateform_error').addClass('alert alert-danger');
                            $.each(response.errors, function (key, error_value) {
                                $('#updateform_error').append('<li>' + error_value + '</list>');
                            });
                            $('.update_student').text("Update");
                        }
                        else if(response.status == 402){
                            $('#updateform_error').html("");
                            $('#success').addClass('alert alert-success');
                            $('#success').text(response.message);
                            $('.update_student').text("Update");
                        }
                        else {
                            $('#updateform_error').html("");
                            $('#success').addClass('alert alert-success');
                            $('#success').text(response.message);
                            $('#editstudentmodal').modal('hide');
                            $('.update_student').text("Update");
                            fetchRecord();

                        }

                    }
                });
            });

          $(document).on('click', '.add_student', function (e) {
             e.preventDefault();
            var data = {
                'name': $('.name').val(),
                'email': $('.email').val()
            }
              $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              });
            $.ajax({
              type:"POST",
                data:data,
                url:"<?php echo e(route('student.store')); ?>",
                datatype: "json",
                success:function (response){
                   if(response.status==400){
                       $('#saveform_error').html();
                       $('#saveform_error').addClass('alert alert-danger');
                       $.each(response.errors, function (key, error_value){
                          $('#saveform_error').append('<li>'+error_value+'</list>');
                       });
                   }
                   else {
                       $('#saveform_error').html();
                       $('#success').addClass('alert alert-success');
                       $('#success').text(response.message);
                       $('#addstudentmodal').modal('hide');
                       $('#addstudentmodal').find('input').val();
                       fetchRecord();
                   }
                }
            });
          });
          $('#checkedall').click(function (){
              $('.checkBoxClass').prop('checked', $(this).prop('checked'));
          });
          $('#deleteAllSelectRecords').click(function (e){
              e.preventDefault();

              var allids = [];
              $("input:checkbox[name=ids]:checked").each(function (){
                 allids.push($(this).val());
              });
              $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              });
              $.ajax({
                  type:"DELETE",
                  url:"<?php echo e(route('student.selected')); ?>",
                  data:{
                      ids:allids
                  },
                  success:function (response){
                     $.each(allids, function (key, val){
                      $('#ids'+val).remove();
                     });
                  }
              });
          });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>